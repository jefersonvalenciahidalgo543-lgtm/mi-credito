const ACCOUNTS_KEY="mi_credito_cuentas_v1";
const SESSION_KEY="mi_credito_sesion_v1";
let currentUser=null;
let KEY="";
let clientes=[];
let clienteActivo=null;
let clienteEditando=null;
const $=id=>document.getElementById(id);
const legacyKey="clientes_creditos_v2";
const getAccounts=()=>JSON.parse(localStorage.getItem(ACCOUNTS_KEY)||"[]");
const setAccounts=a=>localStorage.setItem(ACCOUNTS_KEY,JSON.stringify(a));
const normalizeUser=u=>u.trim().toLowerCase().replace(/[^a-z0-9._-]/g,"");
async function hashPassword(value){
  if(window.crypto?.subtle){const data=new TextEncoder().encode(value),buf=await crypto.subtle.digest("SHA-256",data);return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,"0")).join("")}
  return btoa(unescape(encodeURIComponent(value)));
}
function setAuthMessage(msg,ok=false){const el=$("authMessage");if(el){el.textContent=msg;el.style.color=ok?"#159567":"#b5222b"}}
function mostrarRegistro(){$("loginForm").style.display="none";$("registerForm").style.display="grid";$("authSubtitle").textContent="Crea tu cuenta personal para guardar tu cartera.";setAuthMessage("")}
function mostrarLogin(){$("registerForm").style.display="none";$("loginForm").style.display="grid";$("authSubtitle").textContent="Inicia sesión para entrar a tu cartera.";setAuthMessage("")}
function accountKey(user){return `clientes_creditos_${user.id}`}
function cargarCuenta(user){currentUser=user;KEY=accountKey(user);clientes=JSON.parse(localStorage.getItem(KEY)||"[]");const legacy=localStorage.getItem(legacyKey);if(!clientes.length&&legacy&&getAccounts().length===1){try{clientes=JSON.parse(legacy)||[];save();localStorage.removeItem(legacyKey)}catch(e){}}document.body.classList.add("authenticated");actualizarUsuarioUI();render();preview();actualizarInicio()}
function actualizarUsuarioUI(){const badge=document.querySelector(".admin-badge"),name=document.querySelector(".admin-user");if(badge)badge.textContent=currentUser?.name||"Administrador";if(name)name.textContent=currentUser?.username||""}
function iniciarSesion(){const session=JSON.parse(localStorage.getItem(SESSION_KEY)||"null");if(!session)return false;const user=getAccounts().find(a=>a.id===session.userId);if(!user){localStorage.removeItem(SESSION_KEY);return false}cargarCuenta(user);return true}
async function handleLogin(e){e.preventDefault();const username=normalizeUser($("loginUser").value),pass=$("loginPass").value,account=getAccounts().find(a=>a.username===username);if(!account)return setAuthMessage("Usuario o contraseña incorrectos.");if(await hashPassword(pass)!==account.passwordHash)return setAuthMessage("Usuario o contraseña incorrectos.");localStorage.setItem(SESSION_KEY,JSON.stringify({userId:account.id}));$("loginForm").reset();cargarCuenta(account);}
async function handleRegister(e){e.preventDefault();const name=$("registerName").value.trim(),username=normalizeUser($("registerUser").value),pass=$("registerPass").value,pass2=$("registerPass2").value;if(!name||username.length<3)return setAuthMessage("Escribe un nombre y un usuario válido.");if(pass.length<6)return setAuthMessage("La contraseña debe tener mínimo 6 caracteres.");if(pass!==pass2)return setAuthMessage("Las contraseñas no coinciden.");const accounts=getAccounts();if(accounts.some(a=>a.username===username))return setAuthMessage("Ese usuario ya existe.");const account={id:Date.now().toString(36)+Math.random().toString(36).slice(2,8),name,username,passwordHash:await hashPassword(pass),createdAt:new Date().toISOString()};accounts.push(account);setAccounts(accounts);localStorage.setItem(SESSION_KEY,JSON.stringify({userId:account.id}));$("registerForm").reset();cargarCuenta(account);}
function cerrarSesion(){if(!confirm("¿Quieres cerrar sesión?"))return;localStorage.removeItem(SESSION_KEY);currentUser=null;KEY="";clientes=[];document.body.classList.remove("authenticated","showing-clients");hide("menuModal");mostrarLogin();}
const money=n=>new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP",maximumFractionDigits:0}).format(Number(n)||0);
const esc=t=>String(t??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
const todayISO=()=>{const d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,10)};
const save=()=>currentUser&&localStorage.setItem(KEY,JSON.stringify(clientes));
function calc(prestamo,interes,cuotas){const interesValor=prestamo*interes/100,total=prestamo+interesValor;return{interesValor,total,cuota:cuotas?total/cuotas:0}}
function addPeriod(date,frequency,n){const d=new Date(date+"T12:00:00");if(frequency==="Diario")d.setDate(d.getDate()+n);else if(frequency==="Semanal")d.setDate(d.getDate()+n*7);else if(frequency==="Quincenal")d.setDate(d.getDate()+n*15);else d.setMonth(d.getMonth()+n);return d}
function daysText(date){const diff=Math.ceil((new Date(date+"T23:59:59")-new Date())/86400000);if(diff<=0)return diff===0?"Vence hoy":"Vencido";if(diff===1)return"Vence mañana";if(diff<30)return`Vence en ${diff} días`;const months=Math.floor(diff/30),days=diff%30;return days?`Vence en ${months} mes${months>1?"es":""} ${days} días`:`Vence en ${months} mes${months>1?"es":""}`}
function formatDate(iso){return new Date(iso+"T12:00:00").toLocaleDateString("es-CO",{day:"2-digit",month:"2-digit",year:"numeric"})}
function formatLongDate(date=new Date()){return date.toLocaleDateString("es-CO",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}
function preview(){const r=calc(+$('prestamo').value||0,+$('interes').value||0,+$('cuotas').value||0);$('previewTotal').textContent=money(r.total);$('previewCuota').textContent=money(r.cuota)}
["prestamo","interes","cuotas"].forEach(id=>$(id).addEventListener("input",preview));
$('fechaInicio').value=todayISO();
$('clienteForm').addEventListener('submit',e=>{e.preventDefault();
 const nombre=$('nombre').value.trim(),telefono=$('telefono').value.replace(/\D/g,""),direccion=$('direccion').value.trim(),prestamo=+$('prestamo').value,interes=+$('interes').value,cuotas=+$('cuotas').value,frecuencia=$('frecuencia').value,fechaInicio=$('fechaInicio').value||todayISO();
 if(!nombre||telefono.length<7||prestamo<=0||interes<0||cuotas<1)return alert("Completa correctamente los datos del cliente.");
 const r=calc(prestamo,interes,cuotas),vencimiento=addPeriod(fechaInicio,frecuencia,cuotas).toISOString().slice(0,10);
 clientes.push({id:Date.now(),numero:clientes.length?Math.max(...clientes.map(c=>c.numero||0))+1:1,nombre,telefono,direccion,prestamo,interes,cuotas,frecuencia,fechaInicio,vencimiento,total:r.total,cuota:r.cuota,pagado:0,historial:[]});save();e.target.reset();$('fechaInicio').value=todayISO();preview();cerrarFormulario();render();
 });
function render(){const f=$('buscar').value.toLowerCase().trim();const lista=clientes.filter(c=>`${c.nombre} ${c.telefono} ${c.direccion}`.toLowerCase().includes(f));$('clientes').innerHTML=lista.map(cardList).join('');$('sinClientes').style.display=lista.length?'none':'block'}
function cardList(c){const saldo=Math.max(c.total-c.pagado,0),terminado=saldo<=0;return `<article class="client-row ${terminado?'completed':''}" onclick="abrirCliente(${c.id})"><div class="client-name">${c.numero||''}) ${esc(c.nombre)}</div><div class="client-check">✓✓</div>${terminado?`<div class="client-pill">Termino credito de ${money(c.total)}</div>`:`<div class="client-main">Credito ${money(c.prestamo)} Saldo ${money(saldo)}</div><div class="client-due">${daysText(c.vencimiento)}</div>`}<div class="client-address">${esc(c.direccion||'')}</div></article>`}
$('buscar').addEventListener('input',render);$('menuBtn').onclick=()=>abrirMenu();
function abrirFormulario(){$('nuevoModal').classList.add('show');$('nombre').focus()}function cerrarFormulario(){$('nuevoModal').classList.remove('show')}
function abrirCliente(id){clienteActivo=id;const c=clientes.find(x=>x.id===id);if(!c)return;renderCliente(c);show('clienteModal')}
function renderCliente(c){const saldo=Math.max(c.total-c.pagado,0),pagadas=Math.min(c.cuotas,Math.floor((c.pagado+0.0001)/c.cuota)),pend=Math.max(c.cuotas-pagadas,0),alDia=c.historial.length>0?'Al día':'Al día';$('clienteCard').innerHTML=`<div class="card-head"><h2>${c.numero||''}) ${esc(c.nombre)}</h2><div class="card-icons"><span title="Llamar" onclick="llamar(event,${c.id})">☎</span><span title="Ubicación" onclick="ubicacion(event,${c.id})">●</span><span title="WhatsApp" onclick="whatsapp(event,${c.id})">▣</span></div></div><div class="card-body"><div class="card-top"><input class="amount-input" id="montoAbono" type="number" min="1" value="${Math.min(Math.round(c.cuota),Math.max(saldo,1))}"><div class="card-buttons"><button class="green-btn" onclick="abrirPagoDesdeCard(event,${c.id})">Abona<br>r</button><button class="red-btn" onclick="noPagoDesdeCard(event,${c.id})">No<br>pago</button></div></div><div class="info-grid"><div class="info-item"><span class="info-icon">🛒</span><span>Credito<small>${money(c.prestamo)}</small></span></div><div class="info-item"><span class="info-icon">$</span><span>Saldo<small>${money(saldo)}</small></span></div><div class="info-item"><span class="info-icon">◐</span><span>Interés<small>${c.interes}%</small></span></div><div class="info-item"><span class="info-icon">◆</span><span>${c.frecuencia} ND<small>${money(c.cuota)}</small></span></div><div class="info-item"><span class="info-icon">☑</span><span>${formatDate(c.fechaInicio)}<small></small></span></div><div class="info-item"><span class="info-icon">☒</span><span>${formatDate(c.vencimiento)}<small></small></span></div><div class="info-item"><span class="info-icon">✓✓</span><span>Pago ${pagadas}/${c.cuotas}<small>${money(c.pagado)}</small></span></div><div class="info-item"><span class="info-icon">•</span><span>${alDia}<small></small></span></div></div><div class="due-status"><span class="dot"></span>${terminadoText(c)}</div><div class="card-actions"><button onclick="abrirHistorial(event,${c.id})">Historial</button><button onclick="editarCliente(event,${c.id})">Editar</button><button class="round-menu" onclick="accionesCliente(event,${c.id})">⋮</button></div></div>`}
function terminadoText(c){const saldo=Math.max(c.total-c.pagado,0);return saldo<=0?'Crédito terminado':daysText(c.vencimiento)}
function show(id){$(id).classList.add('show')}function hide(id){$(id).classList.remove('show')}
function abrirPagoDesdeCard(e,id){e.stopPropagation();const v=+$('montoAbono').value;abrirPago(id,v)}
function noPagoDesdeCard(e,id){e.stopPropagation();registrarNoPagoDirecto(id)}
function abrirPago(id,valor=''){clienteActivo=id;const c=clientes.find(x=>x.id===id);if(!c)return;const saldo=Math.max(c.total-c.pagado,0);$('clientePago').textContent=`${c.nombre} · Saldo actual: ${money(saldo)}`;$('valorPago').value=valor||Math.min(Math.round(c.cuota),Math.max(saldo,1));show('pagoModal');setTimeout(()=>{$('valorPago').focus();$('valorPago').select()},50)}
function cerrarPago(){hide('pagoModal')}
function registrarPago(){const c=clientes.find(x=>x.id===clienteActivo),v=+$('valorPago').value,s=Math.max(c.total-c.pagado,0);if(!c||v<=0)return alert('Escribe un abono válido.');if(v>s)return alert(`El abono no puede superar ${money(s)}.`);registrarAbono(c,v);cerrarPago();hide('clienteModal');render();mostrarExito(c,v)}
function registrarAbono(c,v){c.pagado=Math.min(c.total,c.pagado+v);c.historial.push({tipo:'abono',fecha:new Date().toISOString(),valor:v});save()}
function registrarNoPago(){if(!clienteActivo)return;registrarNoPagoDirecto(clienteActivo);cerrarPago();}
function registrarNoPagoDirecto(id){const c=clientes.find(x=>x.id===id);if(!c)return;c.historial.push({tipo:'no_pago',fecha:new Date().toISOString(),valor:0});save();renderCliente(c);alert(`No pago registrado para ${c.nombre}.`)}
function construirMensajeAbono(c,v){const pagadas=Math.min(c.cuotas,Math.round((c.pagado/Math.max(c.cuota,1))*100)/100);const saldo=Math.max(c.total-c.pagado,0);return `Abono Exitoso ✅\n\nHas abonado: ${money(v)}\nNombre: ${c.nombre}\nCredito: ${money(c.prestamo)}\nSaldo: ${money(saldo)}\nValor cuota: ${money(c.cuota)}\nCuotas Pagas: ${pagadas} / ${c.cuotas}\n${formatLongDate()}`}
function abrirWhatsAppAbono(){if(!clienteActivo||!window.ultimoAbono)return;whatsappAbono(clienteActivo,window.ultimoAbono)}
function whatsappAbono(id,v){const c=clientes.find(x=>x.id===id);if(!c)return;let tel=c.telefono;if(tel.length===10&&tel.startsWith('3'))tel='57'+tel;const msg=construirMensajeAbono(c,v);window.open(`https://wa.me/${tel}?text=${encodeURIComponent(msg)}`,'_blank')}
function copiarMensajeAbono(){if(!clienteActivo||!window.ultimoAbono)return;navigator.clipboard?.writeText(construirMensajeAbono(clientes.find(x=>x.id===clienteActivo),window.ultimoAbono)).then(()=>alert('Mensaje copiado.')).catch(()=>alert('No se pudo copiar automáticamente.'))}
function mostrarExito(c,v){
 const pagadas=Math.min(c.cuotas,Math.round((c.pagado/Math.max(c.cuota,1))*100)/100);
 const saldo=Math.max(c.total-c.pagado,0);
 window.ultimoAbono=v;
 const html=`<div class="success-receipt"><div class="success-title">Abono Exitoso <span>✓</span></div><div class="receipt-row"><strong>Has abonado</strong><span>${money(v)}</span></div><div class="receipt-row"><strong>Nombre</strong><span>${esc(c.nombre).slice(0,22)}${c.nombre.length>22?'...':''}</span></div><div class="receipt-row"><strong>Credito</strong><span>${money(c.prestamo)}</span></div><div class="receipt-row"><strong>Saldo</strong><span>${money(saldo)}</span></div><div class="receipt-row"><strong>Valor cuota</strong><span>${money(c.cuota)}</span></div><div class="receipt-row"><strong>Cuotas Pagas</strong><span>${pagadas} / ${c.cuotas}</span></div><div class="receipt-date">${formatLongDate()}</div><div class="receipt-actions"><button class="whatsapp-send" onclick="abrirWhatsAppAbono()">💬 Enviar por WhatsApp</button><button class="copy-send" onclick="copiarMensajeAbono()">Copiar mensaje</button><button class="close-receipt" onclick="cerrarHistorial()">Cerrar</button></div></div>`;
 $('historialContenido').innerHTML=html;show('historialModal')
}
function abrirHistorial(e,id){e.stopPropagation();const c=clientes.find(x=>x.id===id);if(!c)return;let html=`<h2>Historial de ${esc(c.nombre)}</h2><p class="sub">Movimientos registrados</p>`;html+=c.historial.length?c.historial.slice().reverse().map(h=>`<div class="history-item"><span>${h.tipo==='abono'?'Abono':'No pago'}<small>${new Date(h.fecha).toLocaleString('es-CO')}</small></span><b>${h.tipo==='abono'?money(h.valor):'—'}</b></div>`).join(''):'<p>No hay movimientos registrados.</p>';$('historialContenido').innerHTML=html;show('historialModal')}
function cerrarHistorial(){hide('historialModal')}
function whatsapp(e,id){if(e)e.stopPropagation();const c=clientes.find(x=>x.id===id),saldo=Math.max(c.total-c.pagado,0),pagadas=Math.min(c.cuotas,Math.floor((c.pagado+0.0001)/c.cuota));let tel=c.telefono;if(tel.length===10&&tel.startsWith('3'))tel='57'+tel;const msg=construirMensajeAbono(c,c.historial.at(-1)?.valor||0);window.open(`https://wa.me/${tel}?text=${encodeURIComponent(msg)}`,'_blank')}
function llamar(e,id){e.stopPropagation();const c=clientes.find(x=>x.id===id);location.href=`tel:${c.telefono}`}
function ubicacion(e,id){e.stopPropagation();const c=clientes.find(x=>x.id===id);if(!c.direccion)return alert('Este cliente no tiene dirección registrada.');window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(c.direccion)}`,'_blank')}
function editarCliente(e,id){e.stopPropagation();const c=clientes.find(x=>x.id===id);if(!c)return;clienteEditando=id;$('editNombre').value=c.nombre;$('editTelefono').value=c.telefono;$('editDireccion').value=c.direccion||'';$('editPrestamo').value=c.prestamo;$('editInteres').value=c.interes;$('editCuotas').value=c.cuotas;$('editFrecuencia').value=c.frecuencia;$('editFechaInicio').value=c.fechaInicio;$('editSaldo').textContent=money(Math.max(c.total-c.pagado,0));hide('clienteModal');show('editarModal');setTimeout(()=>$('editNombre').focus(),50)}
function cerrarEdicion(){hide('editarModal');clienteEditando=null}
$('editarForm').addEventListener('submit',e=>{e.preventDefault();const c=clientes.find(x=>x.id===clienteEditando);if(!c)return;const nombre=$('editNombre').value.trim(),telefono=$('editTelefono').value.replace(/\D/g,''),direccion=$('editDireccion').value.trim(),prestamo=+$('editPrestamo').value,interes=+$('editInteres').value,cuotas=+$('editCuotas').value,frecuencia=$('editFrecuencia').value,fechaInicio=$('editFechaInicio').value||todayISO();if(!nombre||telefono.length<7||prestamo<=0||interes<0||cuotas<1)return alert('Completa correctamente los datos del cliente.');const r=calc(prestamo,interes,cuotas),vencimiento=addPeriod(fechaInicio,frecuencia,cuotas).toISOString().slice(0,10);c.nombre=nombre;c.telefono=telefono;c.direccion=direccion;c.prestamo=prestamo;c.interes=interes;c.cuotas=cuotas;c.frecuencia=frecuencia;c.fechaInicio=fechaInicio;c.vencimiento=vencimiento;c.total=r.total;c.cuota=r.cuota;c.pagado=Math.min(c.pagado,c.total);save();cerrarEdicion();render();renderCliente(c);show('clienteModal')});
['editPrestamo','editInteres','editCuotas'].forEach(id=>$(id).addEventListener('input',()=>{const c=clientes.find(x=>x.id===clienteEditando);if(c)$('editSaldo').textContent=money(Math.max(calc(+$('editPrestamo').value||0,+$('editInteres').value||0,+$('editCuotas').value||0).total-c.pagado,0))}));
function accionesCliente(e,id){e.stopPropagation();const c=clientes.find(x=>x.id===id);if(confirm(`¿Eliminar a ${c.nombre}?`)){clientes=clientes.filter(x=>x.id!==id);save();hide('clienteModal');render()}}
function cerrarMenu(){hide('menuModal')}
function exportarDatos(){const blob=new Blob([JSON.stringify(clientes,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='clientes-credito.json';a.click();URL.revokeObjectURL(a.href)}
function borrarTodo(){if(confirm('¿Seguro que quieres borrar todos los clientes?')){clientes=[];save();render();cerrarMenu()}}
window.addEventListener('click',e=>{['nuevoModal','clienteModal','pagoModal','editarModal','historialModal','menuModal'].forEach(id=>{if(e.target===$(id))hide(id)})});
// Navegación y funciones de la bandeja de inicio
function irInicio(){document.body.classList.remove('showing-clients');window.scrollTo({top:0,behavior:'smooth'});actualizarInicio()}
function irClientes(){document.body.classList.add('showing-clients');window.scrollTo({top:0,behavior:'smooth'});render()}
function abrirMenu(){show('menuModal')}
function actualizarInicio(){
 const base=clientes.reduce((s,c)=>s+Number(c.prestamo||0),0);
 const fecha=new Date().toLocaleDateString('es-CO',{weekday:'long',day:'numeric'});
 $('homeBase').textContent=money(base); $('homeDate').textContent=fecha;
 if($('infoClientes')){$('infoClientes').textContent=clientes.length;$('infoPrestado').textContent=money(base);$('infoSaldo').textContent=money(clientes.reduce((s,c)=>s+Math.max(Number(c.total||0)-Number(c.pagado||0),0),0));}
}
function verInfo(){actualizarInicio();show('infoModal')}
function abrirCarteras(){show('carterasModal')}
function guardarDatos(){exportarDatos();alert('Copia de seguridad descargada correctamente.')}
function verIngresos(){
 const total=clientes.reduce((s,c)=>s+Number(c.pagado||0),0);
 alert(`Ingresos registrados\n\nTotal recibido: ${money(total)}`)
}
function verEgresos(){alert('Egresos\n\nAquí podrás registrar los gastos de la cartera.')}
function liquidar(){
 const pendientes=clientes.reduce((s,c)=>s+Math.max(Number(c.total||0)-Number(c.pagado||0),0),0);
 alert(`Liquidar cartera\n\nSaldo pendiente: ${money(pendientes)}\n\nSelecciona un cliente desde la cartera para registrar un pago.`)
}
function verHistorialGeneral(){
 const movimientos=clientes.flatMap(c=>(c.historial||[]).map(h=>({...h,nombre:c.nombre}))).sort((a,b)=>new Date(b.fecha)-new Date(a.fecha));
 let html='<h2>Historial general</h2><p class="sub">Todos los movimientos de la cartera</p>';
 html+=movimientos.length?movimientos.slice(0,80).map(h=>`<div class="history-item"><span>${h.tipo==='abono'?'Abono':'No pago'} · ${esc(h.nombre)}<small>${new Date(h.fecha).toLocaleString('es-CO')}</small></span><b>${h.tipo==='abono'?money(h.valor):'—'}</b></div>`).join(''):'<p>No hay movimientos registrados.</p>';
 $('historialContenido').innerHTML=html;show('historialModal')
}
const _renderOriginal=render;
render=function(){_renderOriginal();actualizarInicio()}
actualizarInicio();
// La bandeja de inicio es la pantalla inicial.
document.body.classList.remove('showing-clients');

// Autenticación: la sesión queda guardada en el dispositivo y no vuelve a pedir login.
$("loginForm").addEventListener("submit",handleLogin);
$("registerForm").addEventListener("submit",handleRegister);
if(!iniciarSesion()){document.body.classList.remove("authenticated");mostrarLogin();}

// Instalación como PWA
let deferredInstallPrompt=null;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstallPrompt=e;});
window.addEventListener("appinstalled",()=>{deferredInstallPrompt=null;});
async function instalarApp(){
  if(deferredInstallPrompt){
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt=null;
    return;
  }
  alert("Si estás en Android, abre el menú de Chrome (⋮) y elige 'Instalar aplicación' o 'Agregar a pantalla de inicio'. En iPhone/iPad, usa Compartir → Agregar a pantalla de inicio.");
}
